//Title: Project2Demo.java
//Author: Luke Pederson
//Abstract: This just runs the final project.
//ID: 9786
//Date: 5/9/2012

public class Project2Demo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Project2App test = new Project2App();
	}

}
