<html>
	<?php 
		include_once 'functions.php'; 
		startHeader("Data Types");
	?>
	</head>
	<body onLoad="linkInit()">
		<div id="wrapper">
			<?php displayBanner(); ?>
			<div id="page">
				<div id="page-bgtop">
					<div id="page-bgbtm">
					<div style="clear: both;">&nbsp;</div>
						<div id="content">
							<div class="post">
								<h2 class="title center">Data Types</h2>
								<div class="entry">
								<div id="container"></div>
								<script src="js/datatype.js"></script>
									<p>
										The values that the program needs to save and use are stored as 
										<i>variables</i>. A <i>data type</i> defines what specific type 
										of data a variable will hold; the format of the variable's value 
										or range of values.
									</p>
									<p>
										Variable names can only contain letters, numbers, and/or the underscore 
										character('_'). When naming variables, there are several requirements 
										that need to be met. First, they cannot begin with digits; there can 
										be a number in the variable name, but it cannot be the first character. 
										Second, variables cannot be one of the keywords that C++ reserves; 
										<i> new, break, continue, return, </i> etc... Third, it cannot contain a
										white-space (' ') or an operator (+, -, !, %, *, etc...). Lastly, it is 
										very important to remember that variable names are case-sensitive; the 
										variable <b>NUM</b> and the variable <b>num</b> are completely independant 
										of each other.
									</p>
									
									<p>
										Valid Variable Names
									</p>
									  <p class="code">var</p>
									  <p class="code">Var2</p>
									  <p class="code">num_var</p>
									</br></br>
									<p>
										Invalid Variable Names
									</p>
									  <p class="code">2var</p>
									  <p class="code">Var two</p>
									  <p class="code">namespace</p>
									  <p class="code">var+</p>
									</br></br>
									<p>
										The proper format for declaring a variable:
									</p>
									  <p class="code">data_type <i>variable_name</i>;</p> 
									 </br>
									<p>
										When a variable is declared, it already contains irrelevant garbage 
										data; whatever data is already in that memory location. It does not 
										overwrite the contents of the memory location, it simply allocates 
										it and prepares it to be overwritten. While it is not necessarily 
										required, it's good to get into the habit of assigning all variables 
										with a value. By default, the value of the variable should be set to 
										<i>null</i> or assigned a specific value when it's initialized.										
									</p>
									 </br>
									<p>
										The proper format for declaring a variable and assigning it a value:
									</p>
									  <p class="code">data_type <i>variable_name</i> = value;</p>
									</br></br>
									<h3 class="title">Integers</h3>
									<p>
										Integers are used whenever the variable will be holding a 
										whole numerical value. Integers can be positive or negative 
										values, but they can not contain decimal points; whole numbers only.
									</p>
									<p>Examples:</p>
									  <p class="code">int var = 0;</p>
									  <p class="code">int var = -89;</p>
									</br>
									<p>Error:</p>
									  <p class="code red">int var = P;</p>
									</br>
									<?php showInputTextArea(file_get_contents("./programs/datatypes/integer.txt"),"input1",15); ?>
									<?php showOutputTextArea(compileInput("input1"),"output1",2); ?>
									</br> </br>
									<h3 class="title">Characters</h3>
									<p>
										Essentially, a Character is anything that can be typed on a 
										keyboard; a letter, a number, a space, a symbol, etc... For example, 
										the word "program" consists of 7 characters (9 if you count the 
										quotation marks). "4jfn 2,%@" contains 9 characters (11 if you count 
										the quotation marks). A <i>char</i> can contain any value, but the 
										variable can only contain 1 character.
									</p> 
									<p>A complete list of all characters can be found/defined with the ASCII table</p>
									<p>Examples:</p>
									  <p class="code">char var = 'f';</p>
									  <p class="code">char var = '@';</p>
									</br>
									<p>Error:</p>
									  <p class="code red">char var = 'cst';</p>
									</br>
									<?php showInputTextArea(file_get_contents("./programs/datatypes/character.txt"),"input2",15); ?>
									<?php showOutputTextArea(compileInput("input2"),"output2",2); ?>
									</br> </br>
									<h3 class="title">Boolean</h3>
									<p>
										Boolean values can either be true(1) or false(0). A programmer
										would only want to use a boolean variable if the value should
										have one of two possible states; yes/no, on/off, true/false, etc...
										For example, a light-switch has only two possible states: on or off.
										While we use the keywords "true" and "false" when writing our code, during
										the execution of the program, the computer translates and reads
										those values as 1 or 0. This is why when the below code is executed
										the output will not print "true" or "false" but rather, the value will be 
										represented as a 1 or 0.
									</p>
									<p>Examples:</p>
									  <p class="code">bool var = 0;</p>
									  <p class="code">bool var = 1;</p>
									  <p class="code">bool var = true;</p>
									  <p class="code">bool var = false;</p>
									</br>
									<p>Error:</p>
									  <p class="code red">bool var = c;</p>
									  <p class="code red">bool var = "cst";</p>
									</br>
									<?php showInputTextArea(file_get_contents("./programs/datatypes/boolean.txt"),"input3",15); ?>
									<?php showOutputTextArea(compileInput("input3"),"output3",2); ?>
									</br> </br>
									<h3 class="title">Double</h3>
									<p>
										Doubles are essentially integers that can have decimal points.
									</p>
									<p>Examples:</p>
									  <p class="code">double var = 0;</p>
									  <p class="code">double var = -23;</p>
									  <p class="code">double var = 3.18462;</p>
									</br>
									<p>Error:</p>
									  <p class="code red">double var = c;</p>
									  <p class="code red">double var = "cst";</p>
									</br>
									<?php showInputTextArea(file_get_contents("./programs/datatypes/double.txt"),"input4",15); ?>
									<?php showOutputTextArea(compileInput("input4"),"output4",2); ?>
									</br> </br>
									<h3 class="title">Assignment Statements</h3>
									<p>
										Once we know what variables we will need and what data types that should be,
										how do we manipulate those variables if we need to change there values?  The answer: 
										assignment statements. We can modify the values of the variables by using the <i> +, -, *, /, %</i>
										operators. The first 4 symbols are nothing that should seem to unfamiliar. Addition(+), Subtraction(-),
										multiplication(*), and division(/) are fairly straight forward.
									</p>
									  <p class="code">total = num1 + num2;</p>
									  </br>
									<p>
										This is the proper syntax for adding two numerical values (num1 and num2) and then storing the result
										in another variable (total).
									</p>
									<p>
										As the need for more complex calculations arises, the rules for writing the expressions follows the left-to-right 
										format while honoring the mathmatical order of operations (PEMDAS).  So for example, lets say we needed to calculate
										the grade point average of a student based on there test scores.
									</p>
									  <p class="code">gpa = (test1 + test2 + test3) / 3;</p>
									  </br>
									<p>
										When calculating the average, the total score of all three tests needs to be added up; <i>(test1 + test2 + test3)</i>.
										Since we that total added first - before we divide it by 3 - we need to put parenthesis around the addition section.
										Once that is completed, that value is then divided by 3; <i>/3</i>. Once that value has been calculated, it is then
										assigned to the variable <i>gpa</i>.
									</p>
									<p>
										The <i>%</i> symbol does refer to percentages. It is actually a very important sign that comes up more often than you
										might think. It is called the <i>modulus</i> operator. It works the same way division works, with one very key difference:
										it calculates the remainder rather than the quotient.
									</p>
									   <p class="code">remainder = 10 % 3;</p>
									   </br>
									<p>
										In the above problem, the compiler is dividing the two numbers which would come out to 3.  However, since we used the modulus
										operator instead the value that will assigned to 'remainder' is actually 1. 3 goes into 10 three times which comes out to 9. 10-9=1
										
									</p>
									</br>
									<?php showInputTextArea(file_get_contents("./programs/datatypes/assign_state.txt"),"input5",15); ?>
									<?php showOutputTextArea(compileInput("input5"),"output5",5); ?>
									</br> </br>
								</div>
							</div>
							<div style="clear: both;">&nbsp;</div>
						</div>
					</div>
				</div>
			</div>
			<?php leftColumnNav(); ?>
			<?php displayFooter(); ?>
		</div>		
		<?php restoreScrollLocation(); ?>
	</body>
</html>
