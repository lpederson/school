-- phpMyAdmin SQL Dump
-- version 3.5.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 20, 2012 at 03:53 PM
-- Server version: 5.5.28-cll
-- PHP Version: 5.3.19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pede9786`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `balance` int(11) NOT NULL,
  `lastlogin` datetime NOT NULL,
  `email` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `active`, `balance`, `lastlogin`, `email`) VALUES
(1, 'luke', 'password', 1, 0, '2012-12-13 14:22:50', 'lpederson@csumb.edu'),
(2, 'drew', 'password', 1, 0, '2012-12-06 03:00:00', 'dcallan@csumb.edu'),
(4, 'greg', 'password', 1, 0, '0000-00-00 00:00:00', 'g@google.com'),
(6, 'dcall', 'password', 0, 0, '2012-12-20 15:31:08', ''),
(7, 'lukep', 'pass', 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sellerid` int(11) NOT NULL,
  `buyerid` int(11) NOT NULL,
  `vehicleid` int(11) NOT NULL,
  `pending` tinyint(4) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `sellerid`, `buyerid`, `vehicleid`, `pending`, `price`) VALUES
(10, 4, 7, 3, 1, 13000);

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `make` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` year(4) NOT NULL,
  `price` int(11) NOT NULL,
  `vcondition` varchar(50) NOT NULL,
  `accountid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `type`, `make`, `model`, `year`, `price`, `vcondition`, `accountid`) VALUES
(1, 'car', 'Chevy', 'Cavalier', 2003, 3004, 'used', 1),
(2, 'car', 'Chevy', 'Cavalier', 2005, 40000, 'used', 2),
(3, 'car', 'Subaru', 'WRX', 2012, 13000, 'new', 4),
(4, 'car', 'Honda', 'Accord', 2004, 4000, 'used', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
