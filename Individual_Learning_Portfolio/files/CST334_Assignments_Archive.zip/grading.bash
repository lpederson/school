#!/bin/bash
if [ $# -ne 2 ] 
  then
    echo "Usage: bash ./grading.bash /path/to/dir /path/to/solution.txt"
    exit 1
fi
if [ ! -d "$1" ] 
  then
    echo "$1 directory doesn't exist"
    exit 1
fi
if [ ! -f $2 ]
  then
    echo "solution.txt doesn't exist"
    exit 1
fi

echo '================================='

for file in $1/*.cpp
do
  echo "grading $file ..."
  g++ -o temp$$ $file
  ./temp$$ >> tmp$$.txt
  wrong=$(diff tmp$$.txt $2 | grep '^<' | wc -l)
  score=100
  wrong=$(($wrong*10))
  score=$(($score-$wrong))
  name=$(grep 'Name: ' $file | cut -d" " -f4)
  id=$(grep 'ID: ' $file | cut -d" " -f4)
  echo "$name,$id,$score" >> results$$.txt
  rm tmp$$.txt
  rm temp$$
  echo "done."
done 

echo "================================"
echo
echo "==== Grading by ID ============"
sort -n -k2 -t',' results$$.txt
echo "==============================="
echo
echo "=== Grading by Score =========="
sort -n -k3 -t',' results$$.txt
echo "==============================="

rm ./results$$.txt

