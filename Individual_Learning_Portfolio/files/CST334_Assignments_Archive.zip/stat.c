/*
 * Title: stat.c
 * Abstract: This program demonstrates the usage of stat system call.
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) 
{
    struct stat buf;

    if (stat(argv[1], &buf) < 0 ) {
        printf("Error\n"); 
        exit(-1);
    }

    if (S_ISREG(buf.st_mode))
    {
        //printf("%s: regular file\n", argv[1]);
        char str[100];
	strcpy(str,"ls -l ");
	strcat(str,argv[1]);
	system(str);
    }
    else if (S_ISDIR(buf.st_mode))
    {
        //printf("%s: directory\n", argv[1]);
        char str[100];
	strcpy(str,"ls -l ");
	strcat(str,argv[1]);
	system(str);
    }
    else
    {
        //printf("%s: unknown type\n", argv[1]);
	char str[100];
	strcpy(str,"ls -l ");
	strcat(str,argv[1]);
	system(str);
    }

    return 0;
}
