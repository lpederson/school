#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  char str[100];
  FILE * cmd;
  cmd = popen("pwd","r");
  fgets(str,sizeof(str),cmd);
  str[(strchr(str,'\n')-str)] = '\0';
  strcat(str,"/sample");
  printf("%s",str);
  mkdir(str,S_IRWXU);
  return 0;
}
