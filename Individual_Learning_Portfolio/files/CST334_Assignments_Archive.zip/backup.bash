#!/bin/bash

if [ $# -eq 0 ] 
  then
    echo "Usage ./backup.back filename"
    exit 1
fi
if [ -f "$1" ]
  then
    if [ -f "$1.bak" ] 
      then
        echo "$1.bak already exists"
	echo -n "Do you want to overwrite [Y/N]?: " 
	read overwrite
        if [ "$overwrite" == "y" ] || [ "$overwrite" == "Y" ] 
          then
 	    cp "$1" "$1.bak"
	    echo "Create a backup file called $1.bak"
	else
          exit 1
	fi
    else
      cp "$1" "$1.bak"
      echo "Create a backup file called $1.bak"
    fi
else
  echo "$1 doesnt exist."
fi
