// Author: Luke Pederson
// Title: calculate.c
// ID: 9786

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

FILE * in;
int main(char * args){
  in = fopen("input.txt" , "r");/*
  if(in == NULL){
    printf("Error opening file.");
    exit(1);
  }*/	
  int sum = 0;
  int count = 0;
  int len = 0;
  int size = 100;
  int i;
  char *read = (char*) malloc(sizeof(char) * size);
  char ch = 'a';
  while(ch != EOF){
    ch = getc(in);
    read[len] = ch;
    len++;
    if(ch == '\n'){
      sum +=  atoi(read);
      count++;
      read[len] = 'a';
      len = 0; 
      
    }
  }
 
  printf("Sum: %d\n",sum);
  printf("Avg: %d\n",(sum/count));
  fclose(in);
}

