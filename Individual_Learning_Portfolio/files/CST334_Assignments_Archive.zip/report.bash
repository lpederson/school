#!/bin/bash
if [ $# -ne 1 ] 
  then
    echo "Usage: bash ./report.bash filename"
    exit 1
fi
if [ ! -f "$1" ]
  then
    echo "$1 doesn't exist"
    exit 1
fi
numlines=$(wc -l $1 | cut -f1 -d' ')
if [ $numlines != '9' ] 
  then
    echo "Error in file: incorrect line count"
    echo "Should be 9, is $numlines"
    exit 1
fi

fname=$(sed -n 1p $1 | sed 's/.*: //')
lname=$(sed -n 2p "$1" | sed 's/.*: //')
addr=$(sed -n 3p "$1" | sed 's/.*: //')
city=$(sed -n 4p "$1" | sed 's/.*: //')
state=$(sed -n 5p "$1" | sed 's/.*: //')
zip=$(sed -n 6p "$1" | sed 's/.*: //')
mon=$(sed -n 7p "$1" | sed 's/.*: //' | cut -d "/" -f1)
day=$(sed -n 7p "$1" | sed 's/.*: //' | cut -d "/" -f2)
year=$(sed -n 7p "$1" | sed 's/.*: //' | cut -d "/" -f3)
s1=$(sed -n 8p "$1" | sed 's/.*: //')
s2=$(sed -n 9p "$1" | sed 's/.*: //')
avg=$(( $s1+$s2 ))
avg=$(( $avg/2))

echo "========= Report Card for $lname, $fname ========="
echo "Birthday: $year-$mon-$day"
echo "Address: $addr, $city, $state, $zip"
echo -n "Average: $avg "

if [ $avg -gt 90 ]
  then
    echo "(Excellent)"
elif [ $avg -gt 80 ] 
  then
    echo "(Good)"
elif [ $avg -gt 70 ] 
  then
    echo "(OK)"
else
    echo "(Poor)"
fi

echo "========= End of Report Card ========="
