#!/bin/bash
# Author: Luke Pederson
# Title: Assignment 7
# ID: 9786
# Date: 11.16.12

if [ $# -ne 2 ]
  then
    echo "Usage: classify.bash c_file src_dir"
    return 1
fi

if [ ! -f $1 ]
  then
    echo "c_file doesn't exist"
    exit 1
fi

if [ ! -d $2 ]
  then
    echo "src_dir doesn't exist"
    exit 1
fi
src_file=$( readlink -f $1)
cd "$2"
while read line
  do
    echo "$line" > tmp$$
    f=$( cut -d" " -f1 tmp$$  )
    p=$( cut -d" " -f2  tmp$$  )  
    for file in $f
      do
	if [ "$file" == "$f" ]
          then  
	  continue
	fi
	mv "$file" "$p/$file"
	if [ -e "$p/$file" ]
	  then
            echo "$2/$file moved to $p/$file"
        fi
	done
     cd "$home"
done <$src_file
rm tmp$$
