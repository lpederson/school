#!/bin/bash
#Name: Luke Pederson
#ID: 9786
echo -n "User: "
whoami
echo
cal
echo -n "Current time: "
date +"%I:%M %P"
echo -n "Enter User ID: "
read userID
grep "$userID" /etc/passwd
echo -n "Enter User ID: "
read userID
grep "$userID" /etc/passwd | cut -d ":" -f3
