// Author: Luke Pederson
// Title: histogram.c
// ID: 9786

#include <stdio.h>

#define max 10
int main(){
 
  int i, j, read;
  int counts[max];
  for(i=0;i<=max;i++)
    counts[i] = 0;
  i=0;
  while(i<max){
    printf("Enter a number: ");
    scanf("%d",&read);
    if(read >= 0 && read < max){
       counts[read]++;
       i++;
    }   
  }
  printf("\n");
  for(i=0;i<max;i++){
     printf("%d:",i);
     for(j=0;j<counts[i];j++)
       printf(" *");
     printf("\n");
  }
  printf("\n");
  for(i=0;i<max;i++)
    printf("%d ",i);
  printf("\n");
  for(i-0;i<max;i++)
    printf("--");
  printf("\n");
  for(i=0;i<max;i++){
    for(j=0;j<max;j++)
      if(counts[j] > i)
        printf("* ");
      else
        printf("  ");
     printf("\n");
  }
  return 0;
}
