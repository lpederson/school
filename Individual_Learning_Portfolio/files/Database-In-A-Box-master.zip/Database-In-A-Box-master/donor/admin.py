from django.contrib import admin
from donor.models import Donor, Donation

admin.site.register(Donor)
admin.site.register(Donation)
