from django.contrib import admin
from questions.models import Question

admin.site.register(Question)
